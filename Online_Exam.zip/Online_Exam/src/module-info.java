/**
 * 
 */
/**
 * @author ADMIN
 *
 */
module Online_Exam {
	requires java.desktop;
}